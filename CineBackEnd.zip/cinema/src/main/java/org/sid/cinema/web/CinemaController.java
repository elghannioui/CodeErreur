package org.sid.cinema.web;

import java.awt.print.Pageable;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.sid.cinema.dao.CinemaRepository;
import org.sid.cinema.dao.SalleRepository;
import org.sid.cinema.dao.VilleRepository;
import org.sid.cinema.entities.Cinema;
import org.sid.cinema.entities.Film;
import org.sid.cinema.entities.Salle;
import org.sid.cinema.entities.Ville;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CinemaController {
	@Autowired
	private CinemaRepository cinemaRepository;
	@Autowired
	private VilleRepository villeRepository;
	@Autowired
	private SalleRepository salleRepository;
	
	 @GetMapping(path="/TestC")
	public String listCinema(Model model, @RequestParam(name="page",defaultValue = "0")int page,
			@RequestParam(name="size",defaultValue = "5" )int size,
			@RequestParam(name="keyword",defaultValue = "")String keyword) {
		Page<Cinema> PageTestC=cinemaRepository.findByNameContains(keyword,PageRequest.of(page, size));
		model.addAttribute("TestC", PageTestC.getContent());
		model.addAttribute("pages", new int[PageTestC.getTotalPages()]);
		model.addAttribute("currentPage", page);
		model.addAttribute("size", size);
		model.addAttribute("keyword", keyword);
		
		return "TestC";
	}
    @GetMapping(path = "/deleteCinema")
    public String deleteCinema(Long id,String keyword,int page,int size){
    	cinemaRepository.deleteById(id);
    	return "redirect:/TestC?page="+page+"&size="+size+"&keyword="+keyword;
    }
    @GetMapping(path = "/formCinema")
    public String formCinema(Model model,String Nville) {
    	Ville ville =villeRepository.findByName(Nville);
    	Cinema cinema = new Cinema();
    	cinema.setVille(ville);
    	model.addAttribute("cinema",cinema);
    	return "formCinema";
    }
	@PostMapping(path = "/saveCinema")
	public String saveCinema(Cinema cinema) {
		cinemaRepository.save(cinema);
		return "formCinema";
	}
	
	//Ville action controler
	
	 @GetMapping(path="/TestV")
	public String listVilles(Model model, @RequestParam(name="page",defaultValue = "0")int page,
			@RequestParam(name="size",defaultValue = "5" )int size,
			@RequestParam(name="keyword",defaultValue = "")String keyword) {
		Page<Ville> PageTestV=villeRepository.findByNameContains(keyword,PageRequest.of(page, size));
		model.addAttribute("TestV", PageTestV.getContent());
		model.addAttribute("pages", new int[PageTestV.getTotalPages()]);
		model.addAttribute("currentPage", page);
		model.addAttribute("size", size);
		model.addAttribute("keyword", keyword);
		
		return "TestV";
	}
	    @GetMapping(path = "/formVille")
	    public String formVille(Model model) {
	    	model.addAttribute("ville", new Ville());
	    	return "formVille";
	    }
		@PostMapping(path = "/saveVille")
		public String saveVille(Ville ville) {
			villeRepository.save(ville);
			return "formVille";
		}
	    @GetMapping(path = "/choixVille")
	    public String choixVille(Model model) {
	    List<Ville> listChoix= villeRepository.findAll();
	    model.addAttribute("choixVille", listChoix);
	    return "choixVille";
	    		}

	   @GetMapping(path = "/deleteVille")
	    public String deleteVille(Long id,String keyword,int page,int size){
	    	villeRepository.deleteById(id);
	    
	    	return "redirect:/TestV?page="+page+"&size="+size+"&keyword="+keyword;
	    }
	   
	   // Salle controler
	   
	   @GetMapping(path="/TestS")
		public String listsalles(Model model, @RequestParam(name="page",defaultValue = "0")int page,
				@RequestParam(name="size",defaultValue = "5" )int size,
				@RequestParam(name="keyword",defaultValue = "")String keyword) {
			Page<Salle> PageTestS=salleRepository.findByNameContains(keyword,PageRequest.of(page, size));
			model.addAttribute("TestS", PageTestS.getContent());
			model.addAttribute("pages", new int[PageTestS.getTotalPages()]);
			model.addAttribute("currentPage", page);
			model.addAttribute("size", size);
			model.addAttribute("keyword", keyword);
			
			return "TestS";
			}
		    @GetMapping(path = "/deleteSalle")
		    public String deleteSalle(Long id,String keyword,int page,int size){
		    	salleRepository.deleteById(id);
		    	return "redirect:/TestS?page="+page+"&size="+size+"&keyword="+keyword;
		    }
	  
		
}
